package br.com.generation.ContaBancaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContaBancariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
